=====
Usage
=====

To use ftps in a project::

    import ftps
