# -*- coding: utf-8 -*-

from .ftps import FTPS  # noqa

__author__ = """Javier Collado"""
__email__ = 'javier.collado@gmail.com'
__version__ = '0.1.0'
