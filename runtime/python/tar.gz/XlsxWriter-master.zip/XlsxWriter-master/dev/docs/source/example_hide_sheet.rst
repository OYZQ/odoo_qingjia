.. _ex_hide_sheet:

Example: Hiding Worksheets
==========================

This program is an example of how to hide a worksheet using the
:func:`hide` method.

.. image:: _images/hide_sheet.png

.. literalinclude:: ../../../examples/hide_sheet.py

