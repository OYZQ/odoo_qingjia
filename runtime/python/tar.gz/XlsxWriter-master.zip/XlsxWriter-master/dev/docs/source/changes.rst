:tocdepth: 1

.. _changes:

Changes in XlsxWriter
=====================

This section shows changes and bug fixes in the XlsxWriter module.

.. include:: ../../../Changes
