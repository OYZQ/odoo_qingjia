.. _ex_doc_properties:

Example: Setting Document Properties
====================================

This program is an example setting document properties. See the
:func:`set_properties` workbook method for more details.

.. image:: _images/doc_properties.png

.. literalinclude:: ../../../examples/doc_properties.py

